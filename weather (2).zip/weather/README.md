**Introduction**
This is a weather application developed for the Android mobile platform, using Java as the main 
programming language.

The project utilizes basic components such as LinearLayout and RecyclerView, as well as popular 
libraries including the image loading framework Glide, the network request framework OkHttp, and 
the JSON parsing framework Gson (all necessary additional configurations are included in Gradle).

The main features include displaying the current weather on the homepage, a 7-day weather forecast, 
and additional information such as wind speed and humidity. Users can toggle between Celsius and 
Fahrenheit display modes by clicking the button in the top right corner and share the weather. 
By clicking the plus button in the top left corner, users enter the city list interface, where they 
can search and add cities(Search in city's full name, for example Exeter,London). Clicking different
city cards on the homepage displays weather for different cities; long pressing a city card triggers
a delete button (if all information is deleted, the app defaults to displaying the last added city 
upon reopening). Additionally, at the bottom of the city list interface, there's a data source 
statement and user feedback feature. Users can click the displayed email to launch the email app(Gmail)
and send feedback to the developers via email. The UI adapts to different display screens and 
orientation changes, with data being updated timely.

**Design Principles**
# 1. Main Architecture
Upon launching the app, MainActivity is displayed first. In the onCreate method,
- First, get the Views to display default effects and set click and refresh listeners.
- Second, retrieve the last displayed city and its latitude and longitude from SharedPreferences. 
  If none, display default content.
- Third, clicking the add button in the top right corner enters the city selection page. After 
  selecting a city, return to the previous page, and obtain data through an OkHttp network request. 
  Once data is received, update the UI and save the selected city.

In the onCreate method of CityActivity,
- First, get the Views, set click events, then retrieve the saved city list from SharedPreferences, 
  and display it using an adapter.
- Second, clicking the search bar enters SearchCityActivity. After searching for a city by keyword, 
  return to the previous page, add it to the local data, and display it in RecyclerView.

In the onCreate method of SearchCityActivity,
- First, get the Views and set click events.
- Second, after the user enters a city name, obtain data through a network request, bind it to an 
  adapter, and update the UI display.

## 2. Design Choices
- During development, multiple Activity components were used, and controls were displayed using 
  layout/xml. Components such as LinearLayout, RelativeLayout, CardView, and RecyclerView were 
  utilized.
- SharedPreferences were used to save data generated during user interaction.
- Explicit Intents were used as the medium for data transfer between different Activities, passing 
  city information back and forth.
- Handlers were employed as bridges for data transmission from background threads to the UI thread.
- Context Menus and Option Menus were implemented to provide good interactive behaviors for users.
- Implicit Intents were used to set different actions corresponding to sharing and email feedback
  functionalities.
- Popular libraries such as Glide for image loading, OkHttp for network requests, and Gson for JSON
  parsing were utilized.

# 3. Rationality Analysis
## Aesthetics: 
  Using CardView and RecyclerView to display weather information in a card format not only looks 
  good but is also easy to browse, enhancing the clarity and interactivity of the user interface.
## Functionality: 
  SharedPreferences are used to save users' preferences and chosen cities, allowing them to see the 
  last viewed content upon each app launch, thus providing a personalized user experience.
## Usability: 
  Through the plus button in the top left corner and the settings button in the top right, users can
  easily add cities, switch temperature units, or share weather information, increasing the app's 
  usability and interactivity.
## Accessibility: 
  Using popular libraries like Glide and OkHttp enhances data processing efficiency and accuracy 
  while ensuring the app's stability across different network conditions.

**Challenges and Improvements**
# 1. Challenges
- Some issues were encountered during development, such as obtaining weather data APIs and setting 
  up interfaces. These were resolved by consulting online resources and Android development 
  documentation.
- During testing, it was found that modifying the list's set method within a loop sometimes caused 
  synchronization errors, leading to crashes. This was fixed by modifying the handling logic.

# 2. Future Improvements
- Adding a plugin to display weather layers like global precipitation and temperature, enhancing the
  app's functionality and providing users with more comprehensive weather information, thus helping 
  them better plan their activities and travel.
- Incorporating a location feature to automatically display the weather of the current city on the 
  main interface, offering users a better experience, especially when traveling or on business trips.

