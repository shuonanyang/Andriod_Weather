package com.example.weather.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weather.R;
import com.example.weather.adapter.SearchCityAdapter;
import com.example.weather.bean.City;
import com.example.weather.listener.ItemClickListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;

public class   SearchCityActivity extends AppCompatActivity implements ItemClickListener {
    public static final int PARSE_DATA_CODE = 1;
    public static final String GEO_URL = "http://api.openweathermap.org/geo/1.0/direct?q=%s&limit=20&appid=" + MainActivity.API_KEY;

    //define variables
    RecyclerView rv_city;
    SearchCityAdapter cityAdapter;
    EditText et_search;
    TextView tv_search;
    List<City> cityList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_city);

        // Initialize views by finding their IDs from the layout
        et_search = findViewById(R.id.et_search);
        tv_search = findViewById(R.id.tv_search);
        rv_city = findViewById(R.id.rv_city);
        // Set click listener for the search button to trigger data fetching
        tv_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDataFromNet();
            }
        });
        // Setup RecyclerView for displaying city search results
        setCityRecyclerView();
    }

    // Define a handler to process messages, such as data fetched from the internet
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            // Check message type to handle data parsing
            if (msg.what == PARSE_DATA_CODE) {
                // Parse the JSON data from the network response using Gson
                Gson gson = new Gson();
                List<City> list = gson.fromJson(msg.obj.toString(), new TypeToken<List<City>>() {
                }.getType());
                // Check if the city list is empty and notify the user
                if (list == null) {
                    Toast.makeText(SearchCityActivity.this, "city information does not exist", Toast.LENGTH_SHORT).show();
                } else {
                    // Clear old data and update with new search results
                    cityList.clear();
                    cityList.addAll(list);
                    cityAdapter.notifyDataSetChanged();
                }
            }else if(msg.what==2){
                // Notify the user if there was an error fetching data
                Toast.makeText(SearchCityActivity.this, "get data from network error!", Toast.LENGTH_SHORT).show();
            }
        }
    };

    // Fetch city data from the internet
    private void getDataFromNet() {
        String key = et_search.getText().toString().trim();
        // Check if the search keyword is empty
        if (TextUtils.isEmpty(key)) {
            Toast.makeText(this, "keyword is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        // Start a new thread to fetch data to avoid blocking the UI thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                // Format the URL with the search keyword
                String url = String.format(GEO_URL, key);
                Request request = new Request.Builder().url(url).build();
                // Execute the request asynchronously
                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        // Send an error message if the request fails
                        mHandler.sendEmptyMessage(2);
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                        //Obtain the data returned by the open weathermap from the response
                        String body = response.body().string();
                        //Get an unused message object from the message pool
                        Message message = mHandler.obtainMessage();
                        message.what = PARSE_DATA_CODE;
                        message.obj = body;
                        //Send the message to be processed
                        mHandler.sendMessage(message);
                    }
                });
            }
        }).start();

    }


    // Initialize and set up the RecyclerView for displaying search results
    private void setCityRecyclerView() {
        //Set the layout manager for the RecyclerView
        rv_city.setLayoutManager(new LinearLayoutManager(this));
        //Initialize the adapter with the data list
        cityAdapter = new SearchCityAdapter(cityList);
        //Set the item click listener for the adapter
        cityAdapter.setItemClickListener(this);
        //Attach the adapter to the RecycleView
        rv_city.setAdapter(cityAdapter);
    }

    // Handle item click events for the RecyclerView
    @Override
    public void onItemClick(int position) {
        //Get the slected city from the list
        City city = cityList.get(position);
        //Prepare the intent and set the result for the previous activity
        Intent intent = new Intent();
        intent.putExtra("item", city);
        setResult(RESULT_OK, intent);
        //Close this activity
        finish();
    }
}
