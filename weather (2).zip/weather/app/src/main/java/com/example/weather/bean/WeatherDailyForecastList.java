package com.example.weather.bean;

import java.io.Serializable;
import java.util.List;

public class WeatherDailyForecastList implements Serializable {

    private long dt;
    private String sunrise;
    private String sunset;
    private Temp temp;
    private Main main;
    private String pressure;
    private String humidity;
    private List<Weather> weather;
    private String speed;
    private String deg;
    private String gust;
    private String pop; 
    private String dt_txt;

    public String getDt_txt() {
        return dt_txt;
    }

    public void setDt_txt(String dt_txt) {
        this.dt_txt = dt_txt;
    }

    public void setDt(long dt) {
        this.dt = dt;
    }
    public long getDt() {
        return dt;
    }

    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public void setSunrise(String sunrise) {
        this.sunrise = sunrise;
    }
    public String getSunrise() {
        return sunrise;
    }

    public void setSunset(String sunset) {
        this.sunset = sunset;
    }
    public String getSunset() {
        return sunset;
    }

    public void setTemp(Temp temp) {
        this.temp = temp;
    }
    public Temp getTemp() {
        return temp;
    }

    public void setPressure(String pressure) {
        this.pressure = pressure;
    }
    public String getPressure() {
        return pressure;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }
    public String getHumidity() {
        return humidity;
    }

    public void setWeather(List<Weather> weather) {
        this.weather = weather;
    }
    public List<Weather> getWeather() {
        return weather;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }
    public String getSpeed() {
        return speed;
    }

    public void setDeg(String deg) {
        this.deg = deg;
    }
    public String getDeg() {
        return deg;
    }

    public void setGust(String gust) {
        this.gust = gust;
    }
    public String getGust() {
        return gust;
    } 

    public void setPop(String pop) {
        this.pop = pop;
    }
    public String getPop() {
        return pop;
    }
  
}
