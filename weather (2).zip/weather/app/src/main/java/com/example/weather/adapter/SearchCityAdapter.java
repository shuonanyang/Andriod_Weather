package com.example.weather.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weather.R;
import com.example.weather.bean.City;
import com.example.weather.listener.ItemClickListener;
import com.rainy.weahter_bg_plug.WeatherBg;

import java.util.List;

public class SearchCityAdapter extends RecyclerView.Adapter<SearchCityAdapter.VH> {
    // List holding city information
    List<City> cityList;
    // Listener for handling click events on city items
    ItemClickListener itemClickListener;

    // Setter for the item click listener
    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
    // Constructor initializes the list of cities
    public SearchCityAdapter(List<City> cityList) {
        this.cityList = cityList;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the city item layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_city, parent, false);
        // Return a new ViewHolder instance
        return new VH(view);
    }

    // Bind city data to the ViewHolder
    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {

        City data = cityList.get(position);
        // Set the text for city, country, state, latitude, and longitude
        holder.tv_city.setText( data.getCountry() + "\t\t" + data.getState() + "\t\t" + data.getName());
        holder.tv_range.setText(String.format("lat %s° \t\tlon %s°", data.getLat(), data.getLon()));
        // Set click listener for the itemView
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemClickListener != null) {
                    // Notify click event with position
                    itemClickListener.onItemClick(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        // Return the total number of city items
        return cityList.size();
    }

    // ViewHolder class for city items
    class VH extends RecyclerView.ViewHolder {
        // TextViews for displaying city and location details
        TextView tv_city, tv_range;

        public VH(@NonNull View itemView) {
            super(itemView);
            // Initialize TextViews by finding them by ID
            tv_range = itemView.findViewById(R.id.tv_range);
            tv_city = itemView.findViewById(R.id.tv_city);

        }
    }
}
