package com.example.weather.utils;

import com.rainy.weahter_bg_plug.utils.WeatherUtil;

import java.math.BigDecimal;

public class WeatherUtils {

    public static double changeF2C(double temp) {
        // Create a BigDecimal object for the conversion formula to maintain precision.
        BigDecimal db = new BigDecimal((temp - 32) / 1.8);
        // Return the converted value, rounded half up to 2 decimal places.
        return db.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    public static double changeC2F(double temp) {
        // Create a BigDecimal object for the conversion formula to maintain precision.
        BigDecimal db = new BigDecimal(32 + temp * 1.8);
        // Return the converted value, rounded half up to 2 decimal places.
        return db.setScale(2,BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    //Setting the weather background
    public static String weahterBg(String desc) {
        String bg = "";
        if (desc.contains("clear")) {
            bg = WeatherUtil.WeatherType.sunny;
        } else if (desc.contains("cloud")) {
            bg = WeatherUtil.WeatherType.cloudy;
        } else if (desc.contains("thunderstorm")) {
            bg = WeatherUtil.WeatherType.thunder;
        } else if (desc.contains("drizzle")) {
            bg = WeatherUtil.WeatherType.lightRainy;
        } else if (desc.contains("sleet")) {
            bg = WeatherUtil.WeatherType.middleSnow;
        } else if (desc.contains("snow")) {
            bg = WeatherUtil.WeatherType.middleSnow;
        } else if (desc.contains("rain")) {
            bg = WeatherUtil.WeatherType.middleRainy;
        } else if (desc.contains("ash")) {
            bg = WeatherUtil.WeatherType.foggy;
        } else if (desc.contains("smoke")) {
            bg = WeatherUtil.WeatherType.foggy;
        } else if (desc.contains("sand")) {
            bg = WeatherUtil.WeatherType.dusty;
        } else if (desc.contains("haze")) {
            bg = WeatherUtil.WeatherType.hazy;
        } else if (desc.contains("dust")) {
            bg = WeatherUtil.WeatherType.dusty;
        } else if (desc.contains("mist")) {
            bg = WeatherUtil.WeatherType.hazy;
        } else if (desc.contains("fog")) {
            bg = WeatherUtil.WeatherType.foggy;
        } else{
            bg = WeatherUtil.WeatherType.sunnyNight;
        }
        return bg;
    }



}
