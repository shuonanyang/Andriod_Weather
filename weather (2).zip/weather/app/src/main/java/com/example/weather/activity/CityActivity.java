package com.example.weather.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weather.adapter.CityAdapter;
import com.example.weather.R;
import com.example.weather.adapter.HourlyAdapter;
import com.example.weather.bean.City;
import com.example.weather.bean.CurrentWeatherBean;
import com.example.weather.listener.ItemClickListener;
import com.example.weather.view.RecyclerViewWithContextMenu;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class CityActivity extends AppCompatActivity implements ItemClickListener {
    //Key for storing city set in SharedPreferences
    public static final String LOCAL_CITY_SET = "local_city_set";
    //Request code for starting activity for result
    public static final int REQUEST_CODE = 999;

    //Define variables
    RecyclerViewWithContextMenu rv_city;
    CityAdapter cityAdapter;
    TextView tv_search, tv_foot;
    List<String> cityList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the content view to the city activity layout
        setContentView(R.layout.activity_city);

        // Initialize views by finding them by ID
        tv_search = findViewById(R.id.tv_search);
        rv_city = findViewById(R.id.rv_city);
        tv_foot = findViewById(R.id.tv_foot);

        // Set OnClickListener for the footer TextView to send an email
        tv_foot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse("mailto:shuonanyang992@gmail.com");
                // Intent to send an email
                Intent data = new Intent(Intent.ACTION_SENDTO);
                data.setData(uri);
                startActivity(Intent.createChooser(data, "Email App"));
            }
        });
        // Set OnClickListener for the search TextView to start the SearchCityActivity
        tv_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent to start SearchCityActivity
                Intent intent = new Intent(CityActivity.this, SearchCityActivity.class);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });
        // Setup RecyclerView for displaying cities
        setCityRecyclerView();
        // Fetch and display local city list from SharedPreferences
        getLocalCityList();
        // Register RecyclerView for context menu
        registerForContextMenu(rv_city);
    }

    private void getLocalCityList() {
        //Get sharedpreferences object
        SharedPreferences sp = getSharedPreferences(MainActivity.SP_NAME, MODE_PRIVATE);
        // Fetch saved city set from SharedPreferences
        Set<String> citySet = sp.getStringSet(LOCAL_CITY_SET, null);
        //Update data through adapter
        if (citySet != null) {
            cityList.clear();
            cityList.addAll(citySet);
            // Notify adapter about data change
            cityAdapter.notifyDataSetChanged();
        }

    }


    private void setCityRecyclerView() {
        // Set layout manager for RecyclerView
        rv_city.setLayoutManager(new LinearLayoutManager(this));
        cityAdapter = new CityAdapter(cityList);
        // Set item click listener for adapter
        cityAdapter.setItemClickListener(this);
        // Set adapter for RecyclerView
        rv_city.setAdapter(cityAdapter);
    }


    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        // Check if the selected menu item is delete
        if (item.getItemId() == R.id.menu_del) {
            // Get context menu info
            RecyclerViewWithContextMenu.RecyclerViewContextInfo menuInfo = (RecyclerViewWithContextMenu.RecyclerViewContextInfo) item.getMenuInfo();
            String c = cityList.get(menuInfo.getPosition());

            //Get sharedpreferences object
            SharedPreferences sp = getSharedPreferences(MainActivity.SP_NAME, MODE_PRIVATE);
            // Fetch saved city set from SharedPreferences
            Set<String> citySet = sp.getStringSet(LOCAL_CITY_SET, null);
            //Update data through adapter
            if (citySet != null) {
                // Convert set to list for manipulation
                ArrayList<String> strings = new ArrayList<>(citySet);
                // Find index of the city in list
                int i = strings.indexOf(c);
                if(i>=0){
                    strings.remove(i);
                    // Save updated city set to SharedPreferences
                    sp.edit().putStringSet(LOCAL_CITY_SET, new LinkedHashSet<>(strings)).commit();
                    cityList.remove(menuInfo.getPosition());
                    cityAdapter.notifyDataSetChanged();
                }

            }

        }
        // Call the superclass implementation
        return super.onContextItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        // Inflate context menu for cities
        getMenuInflater().inflate(R.menu.menu_city_context, menu);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Determine if requestCode and requestCode match
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            // Retrieve the returned data from the intent
            City city = (City) data.getSerializableExtra("item");
            String item = city.getName() + ";-;-;-;" + city.getLat() + ";" + city.getLon();
            // Retrieve the returned data from the intent
            cityList.add(0, item);
            // Notify the adapter to refresh and display the latest data
            cityAdapter.notifyDataSetChanged();

            // Save the latest city in SharedPreferences
            SharedPreferences sp = getSharedPreferences(MainActivity.SP_NAME, MODE_PRIVATE);
            Set<String> citySet = sp.getStringSet(LOCAL_CITY_SET, null);
            if (citySet == null) {
                // Initialize city set if null
                citySet = new HashSet<>();
            }
            citySet.add(item);
            sp.edit().putStringSet(LOCAL_CITY_SET, citySet).commit();
        }
    }

    @Override
    public void onItemClick(int position) {
        // Get city data from list
        String data = cityList.get(position);
        // Split city data to extract information
        String[] split = data.split(";");
        // Create new intent
        Intent intent = new Intent();
        intent.putExtra("city", split[0]);
        intent.putExtra("lat", split[4]);
        intent.putExtra("lon", split[5]);
        // Set result with intent
        setResult(RESULT_OK, intent);
        finish();
    }
}
