package com.example.weather.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.weather.adapter.DailyAdapter;
import com.example.weather.adapter.HourlyAdapter;
import com.example.weather.R;
import com.example.weather.bean.CurrentWeatherBean;
import com.example.weather.bean.WeatherDailyForecast;
import com.example.weather.bean.WeatherDailyForecastList;
import com.example.weather.bean.Wind;
import com.example.weather.utils.WeatherUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rainy.weahter_bg_plug.WeatherBg;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;

public class MainActivity extends AppCompatActivity {
    // Constant fields for request codes, API keys, and URL formats
    public static final int REQUEST_CODE = 999;
    public static final int PARSE_CURRENT_DATA_CODE = 1;
    public static final int PARSE_FORECAST_DATA_CODE = 3;
    public static final int PARSE_HOURLY_DATA_CODE = 4;
    public static final int PARSE_AIR_POLLUTION_DATA_CODE = 5;
    public static final String SP_NAME = "weather_sp_file";
    public static final String LAST_LOCATION = "last_location";
    public static final String LAST_LOCATION_LON = "last_location_lon";
    public static final String LAST_LOCATION_LAT = "last_location_lat";
    public static final String LAST_LOCATION_DEFAULT = "No Select";
    public static final String API_KEY = "11eb1d0ad7c89d0db01fb2b4e1be1b7b";
    public static final String BASE_URL = "https://api.openweathermap.org/data/2.5/";
    public static final String URL_CURRENT_WEATHER = "weather?units=metric&lat=%s&lon=%s&appid=" + API_KEY;
    public static final String URL_WEATHER_FORECAST = "forecast/daily?units=metric&lat=%s&lon=%s&appid=" + API_KEY;
    public static final String URL_AIR_POLLUTION = "http://api.openweathermap.org/data/2.5/air_pollution?units=metric&lat=%s&lon=%s&appid=" + API_KEY;
    public static final String URL_WEATHER_HOURLY_FORECAST = "https://pro.openweathermap.org/data/2.5/forecast/hourly?units=metric&lat=%s&lon=%s&&cnt=24&appid=" + API_KEY;


    // Variable definitions for UI components and data models
    WeatherBg wb;
    RecyclerView rv_hourly, rv_daily;
    HourlyAdapter hourlyAdapter;
    DailyAdapter dailyAdapter;
    SwipeRefreshLayout srl;
    ImageView iv_add;
    TextView tv_city, tv_temperature, tv_weather, tv_max, tv_min, tv_alert_name, tv_alert_desc, tv_wind, tv_rain;
    //Model for current weather data
    CurrentWeatherBean currentWeatherBean;
    //List for daily forecasts
    List<WeatherDailyForecastList> weatherDailyForecastLists = new ArrayList<>();
    //List for hourly forecasts
    List<WeatherDailyForecastList> weatherhourlyForecastLists = new ArrayList<>();
    // Longitude and latitude of the current location
    String lon, lat;
    public int mode = 0;//1=Fahrenheit,0=Degree Celsius

    // Handler to process messages and update UI accordingly
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            //Change the refresh status of the control
            srl.setRefreshing(false);

            if (msg.what == PARSE_CURRENT_DATA_CODE) {
                //Analyzing data from the network
                Gson gson = new Gson();
                currentWeatherBean = gson.fromJson(msg.obj.toString(), new TypeToken<CurrentWeatherBean>() {
                }.getType());
                //Refresh data on the page
                updateWeather();
            } else if (msg.what == PARSE_FORECAST_DATA_CODE) {
                Gson gson = new Gson();
                WeatherDailyForecast forecast = gson.fromJson(msg.obj.toString(), new TypeToken<WeatherDailyForecast>() {
                }.getType());
                List<WeatherDailyForecastList> list = forecast.getList();
                weatherDailyForecastLists.clear();
                weatherDailyForecastLists.addAll(list);
                //Refresh data on the page
                dailyAdapter.notifyDataSetChanged();
            } else if (msg.what == PARSE_HOURLY_DATA_CODE) {
                Gson gson = new Gson();
                WeatherDailyForecast forecast = gson.fromJson(msg.obj.toString(), new TypeToken<WeatherDailyForecast>() {
                }.getType());
                List<WeatherDailyForecastList> list = forecast.getList();
                weatherhourlyForecastLists.clear();
                weatherhourlyForecastLists.addAll(list);
                //Refresh data on the page
                hourlyAdapter.notifyDataSetChanged();
            } else if (msg.what == PARSE_AIR_POLLUTION_DATA_CODE) {
                try {
                    JSONObject object = new JSONObject(msg.obj.toString());
                    int aqi = object.getJSONArray("list").getJSONObject(0).getJSONObject("main").getInt("aqi");

                    //1 = Good, 2 = Fair, 3 = Moderate, 4 = Poor, 5 = Very Poor.
                    if (aqi == 1) {
                        tv_alert_desc.setText("Good");
                    } else if (aqi == 2) {
                        tv_alert_desc.setText("Fair");
                    } else if (aqi == 3) {
                        tv_alert_desc.setText("Moderate");
                    } else if (aqi == 4) {
                        tv_alert_desc.setText("Poor");
                    } else {
                        tv_alert_desc.setText("Very Poor");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                // Handle network error messages
            } else if (msg.what == 2) {
                Toast.makeText(MainActivity.this, "get data from network error!", Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set content view to main activity layout
        setContentView(R.layout.activity_main);
        // Initialize UI components by finding them by ID
        tv_city = findViewById(R.id.tv_city);
        tv_temperature = findViewById(R.id.tv_temperature);
        tv_weather = findViewById(R.id.tv_weather);
        tv_min = findViewById(R.id.tv_min);
        tv_max = findViewById(R.id.tv_max);
        tv_alert_name = findViewById(R.id.tv_alert_name);
        tv_alert_desc = findViewById(R.id.tv_alert_desc);
        tv_wind = findViewById(R.id.tv_wind);
        tv_rain = findViewById(R.id.tv_rain);
        iv_add = findViewById(R.id.iv_add);
        wb = findViewById(R.id.wb);
        rv_hourly = findViewById(R.id.rv_hourly);
        rv_daily = findViewById(R.id.rv_daily);
        srl = findViewById(R.id.srl);

        // Setup swipe refresh listener for updating weather data
        srl.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (lon != "0" && lat != "0") {
                    refresh();
                }
            }
        });

        // Set onClickListener for the add city button to navigate to CityActivity
        iv_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CityActivity.class);
                startActivityForResult(intent, REQUEST_CODE);
            }
        });
        // Setup RecyclerView for hourly and daily weather forecasts
        setHourlyRecyclerView();
        setDailyRecyclerView();
        // set the last location city, if not, display the default page
        setLocationText();

    }

    //Get weather data for the current day
    private void getCurrentFromNet() {
        //Querying interface data with Okhttp via threaded approach
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                //Splice url based on latitude and longitude
                String url = BASE_URL + String.format(URL_CURRENT_WEATHER, lat, lon);
                //Building Request Objects
                Request request = new Request.Builder().url(url).build();
                //Send an asynchronous request
                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        //Send the error message to the handler
                        mHandler.sendEmptyMessage(2);
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                        //Obtain the data returned by the open weathermap from the response
                        String body = response.body().string();
                        //Get an unused message object from the message pool
                        Message message = mHandler.obtainMessage();
                        message.what = PARSE_CURRENT_DATA_CODE;
                        message.obj = body;
                        mHandler.sendMessage(message);
                    }
                });
            }
        }).start();

    }

    private void getAirpollutionFromNet() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                //Splice url based on latitude and longitude
                String url = String.format(URL_AIR_POLLUTION, lat, lon);
                //Building Request Objects
                Request request = new Request.Builder().url(url).build();
                //Send an asynchronous request
                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        //Send the error message to the handler
                        mHandler.sendEmptyMessage(2);
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                        //Obtain the data returned by the open weathermap from the response
                        String body = response.body().string();
                        //Get an unused message object from the message pool
                        Message message = mHandler.obtainMessage();
                        message.what = PARSE_AIR_POLLUTION_DATA_CODE;
                        message.obj = body;
                        mHandler.sendMessage(message);
                    }
                });
            }
        }).start();

    }

    //Same logic
    private void getDailyForecastFromNet() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                String url = BASE_URL + String.format(URL_WEATHER_FORECAST, lat, lon);
                Request request = new Request.Builder().url(url).build();
                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        mHandler.sendEmptyMessage(2);
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                        //Obtain the data returned by the open weathermap from the response
                        String body = response.body().string();
                        //Get an unused message object from the message pool
                        Message message = mHandler.obtainMessage();
                        message.what = PARSE_FORECAST_DATA_CODE;
                        message.obj = body;
                        mHandler.sendMessage(message);
                    }
                });
            }
        }).start();

    }

    //Same logia
    private void getHourlyForecastFromNet() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                String url = String.format(URL_WEATHER_HOURLY_FORECAST, lat, lon);
                Request request = new Request.Builder().url(url).build();
                client.newCall(request).enqueue(new okhttp3.Callback() {
                    @Override
                    public void onFailure(okhttp3.Call call, IOException e) {
                        mHandler.sendEmptyMessage(2);
                    }

                    @Override
                    public void onResponse(okhttp3.Call call, okhttp3.Response response) throws IOException {
                        //Obtain the data returned by the open weathermap from the response
                        String body = response.body().string();
                        //Get an unused message object from the message pool
                        Message message = mHandler.obtainMessage();
                        message.what = PARSE_HOURLY_DATA_CODE;
                        message.obj = body;
                        mHandler.sendMessage(message);
                    }
                });
            }
        }).start();

    }

    private void updateWeather() {
        //Get the description text returned by the interface
        String desc = currentWeatherBean.getWeather().get(0).getDescription();
        //Display different weather backgrounds based on different fields
        wb.changeWeather(WeatherUtils.weahterBg(desc));

        //Setting up weather conditions
        tv_weather.setText(desc);
        if(mode==0){
            //Setting temperature
            tv_temperature.setText(currentWeatherBean.getMain().getTemp() + "°");
            //Setting the maximum temperature
            tv_max.setText(currentWeatherBean.getMain().getTemp_max() + "°");
            //Setting the minimum temperature
            tv_min.setText(currentWeatherBean.getMain().getTemp_min() + "°");
        }else{
            //Setting temperature
            tv_temperature.setText(WeatherUtils.changeF2C(currentWeatherBean.getMain().getTemp()) + "°");
            //Setting the maximum temperature
            tv_max.setText(WeatherUtils.changeF2C(currentWeatherBean.getMain().getTemp_max()) + "°");
            //Setting the minimum temperature
            tv_min.setText(WeatherUtils.changeF2C(currentWeatherBean.getMain().getTemp_min()) + "°");
        }


        //Access to wind data
        Wind wind = currentWeatherBean.getWind();
        int deg = wind.getDeg();
        double gust = wind.getGust();
        double speed = wind.getSpeed();
        //Setting the wind direction data
        tv_wind.setText("speed " + speed + "m/s\ngust " + gust + "m/s\ndeg " + deg + "°");
        //Setting other available data
        tv_rain.setText("humidity " + currentWeatherBean.getMain().getHumidity() + "%\npressure " + currentWeatherBean.getMain().getPressure());
    }

    private void setLocationText() {
        //Get sharedpreferences object
        SharedPreferences sp = getSharedPreferences(SP_NAME, MODE_PRIVATE);

        //Get last save data info
        String last_location = sp.getString(LAST_LOCATION, LAST_LOCATION_DEFAULT);
        tv_city.setText(last_location);
        lon = sp.getString(LAST_LOCATION_LON, "0");
        lat = sp.getString(LAST_LOCATION_LAT, "0");
        //If not set, interface data is not requested
        if (lon != "0" && lat != "0") {
            refresh();
        }
    }

    private void setHourlyRecyclerView() {
        hourlyAdapter = new HourlyAdapter(weatherhourlyForecastLists);
        // set direction to horizontal
        LinearLayoutManager manager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        rv_hourly.setLayoutManager(manager);
        rv_hourly.setAdapter(hourlyAdapter);
    }

    private void setDailyRecyclerView() {
        dailyAdapter = new DailyAdapter(weatherDailyForecastLists);
        // Set direction to horizontal
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rv_daily.setLayoutManager(manager);
        rv_daily.setAdapter(dailyAdapter);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Determine if requestCode and requestCode match
        if (resultCode == RESULT_OK && requestCode == REQUEST_CODE) {
            lat = data.getStringExtra("lat");
            lon = data.getStringExtra("lon");
            String city = data.getStringExtra("city");
            tv_city.setText(city);
            srl.setRefreshing(true);
            mode = 0;
            // Get sharedpreferences object
            SharedPreferences sp = getSharedPreferences(SP_NAME, MODE_PRIVATE);
            sp.edit().putString(LAST_LOCATION_LON, lon + "")
                    .putString(LAST_LOCATION_LAT, lat + "")
                    .putString(LAST_LOCATION, tv_city.getText().toString())
                    .commit();

            refresh();
        }
    }

    private void refresh() {
        getCurrentFromNet();
        getAirpollutionFromNet();
        getHourlyForecastFromNet();
        getDailyForecastFromNet();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Load xml menu directory
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // Check which menu item was clicked
        if (item.getItemId() == R.id.menu_degree) {
            // Set the mode to 0 indicating Celsius
            mode = 0;
            // Update the temperature, maximum, and minimum temperature views to display in Celsius
            tv_temperature.setText(currentWeatherBean.getMain().getTemp() + "°");
            tv_max.setText(currentWeatherBean.getMain().getTemp_max() + "°");
            tv_min.setText(currentWeatherBean.getMain().getTemp_min() + "°");

            // Notify the adapters for the daily and hourly weather forecasts that the data has changed
            dailyAdapter.notifyDataSetChanged();
            hourlyAdapter.notifyDataSetChanged();
        } else if (item.getItemId() == R.id.menu_fahrenheit) {
            // Set the mode to 1 indicating Fahrenheit
            mode = 1;
            // Convert the temperature from Celsius to Fahrenheit and update the views
            tv_temperature.setText(WeatherUtils.changeC2F(currentWeatherBean.getMain().getTemp()) + "°");
            tv_max.setText(WeatherUtils.changeC2F(currentWeatherBean.getMain().getTemp_max()) + "°");
            tv_min.setText(WeatherUtils.changeC2F(currentWeatherBean.getMain().getTemp_min()) + "°");

            // Notify the adapters for the daily and hourly weather forecasts that the data has changed
            dailyAdapter.notifyDataSetChanged();
            hourlyAdapter.notifyDataSetChanged();
        } else if (item.getItemId() == R.id.menu_share) {
            // If the user selects the share option
            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);

            // Specify the content to send
            shareIntent.putExtra(Intent.EXTRA_TEXT, "This is a great weather application");
            // Specify the type of content to send
            shareIntent.setType("text/plain");
            // Start the share intent to allow the user to choose how to share the text
            startActivity(Intent.createChooser(shareIntent, "Share"));
        }
        // Call the superclass implementation for any unhandled menu items
        return super.onOptionsItemSelected(item);
    }

}
