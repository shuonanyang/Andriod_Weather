package com.example.weather.bean;

import java.io.Serializable;

public class Sys implements Serializable {

    private int type;
    private long id;
    private String country;
    private long sunrise;
    private long sunset;
    public void setType(int type) {
        this.type = type;
    }
    public int getType() {
        return type;
    }

    public void setId(long id) {
        this.id = id;
    }
    public long getId() {
        return id;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    public String getCountry() {
        return country;
    }

    public void setSunrise(long sunrise) {
        this.sunrise = sunrise;
    }
    public long getSunrise() {
        return sunrise;
    }

    public void setSunset(long sunset) {
        this.sunset = sunset;
    }
    public long getSunset() {
        return sunset;
    }

}
