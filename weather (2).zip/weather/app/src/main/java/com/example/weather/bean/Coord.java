package com.example.weather.bean;

import java.io.Serializable;

public class Coord implements Serializable {

    private double lon;
    private double lat;
    public void setLon(double lon) {
        this.lon = lon;
    }
    public double getLon() {
        return lon;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }
    public double getLat() {
        return lat;
    }

}
