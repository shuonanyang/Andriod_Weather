package com.example.weather.bean;

import java.io.Serializable;
import java.util.List;

public class WeatherDailyForecast  implements Serializable {

    private City city;
    private String cod;
    private double message;
    private int cnt;
    private List<WeatherDailyForecastList> list;
    public void setCity(City city) {
        this.city = city;
    }
    public City getCity() {
        return city;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }
    public String getCod() {
        return cod;
    }

    public void setMessage(double message) {
        this.message = message;
    }
    public double getMessage() {
        return message;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }
    public int getCnt() {
        return cnt;
    }

    public void setList(List<WeatherDailyForecastList> list) {
        this.list = list;
    }
    public List<WeatherDailyForecastList> getList() {
        return list;
    }

}