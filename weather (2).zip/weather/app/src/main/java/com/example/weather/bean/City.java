package com.example.weather.bean;

import java.io.Serializable;

public class City implements Serializable {
//    {
//        "name": "London",
//            "lat": 51.5073219,
//            "lon": -0.1276474,
//            "country": "GB",
//            "state": "England"
//    }


    private String name;
    private String lon;
    private String lat;
    private String country;
    private String state;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLon() {
        return lon;
    }

    public void setLon(String lon) {
        this.lon = lon;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
