package com.example.weather.listener;

public interface ItemClickListener {
    void onItemClick(int position);
}
