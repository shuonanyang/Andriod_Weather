package com.example.weather.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ContextMenu;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewWithContextMenu extends RecyclerView {
    private final static String TAG = "RVWCM";

    private RecyclerViewContextInfo mContextInfo = new RecyclerViewContextInfo();
    // Constructor for initializing the RecyclerView with a context
    public RecyclerViewWithContextMenu(Context context) {
        super(context);
    }
    // Constructor that takes in context and AttributeSet for initializing RecyclerView from XML
    public RecyclerViewWithContextMenu(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
    //Constructor for styling the RecyclerView with a default style
    public RecyclerViewWithContextMenu(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public boolean showContextMenuForChild(View originalView, float x, float y) {
        // Retrieve the layout manager to find the position of the item that was long-clicked
        LayoutManager layoutManager = getLayoutManager();
        if(layoutManager != null) {
            // Get the position of the child view that is long-clicked
            int position = layoutManager.getPosition(originalView);
            // Set the position in the custom ContextMenuInfo
            mContextInfo.mPosition = position;
        }
        // Call the superclass implementation to actually show the context menu
        return super.showContextMenuForChild(originalView, x, y);
    }

    @Override
    protected ContextMenu.ContextMenuInfo getContextMenuInfo() {
        // Return the custom ContextMenuInfo which contains the position of the long-clicked item
        return mContextInfo;
    }

    // Inner class to hold context menu information, specifically the position of the long-clicked item
    public static class RecyclerViewContextInfo implements ContextMenu.ContextMenuInfo {
        private int mPosition = -1;
        // Getter method for the position
        public int getPosition() {
            return mPosition;
        }
    }
}