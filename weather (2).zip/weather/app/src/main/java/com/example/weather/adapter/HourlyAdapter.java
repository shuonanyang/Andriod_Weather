package com.example.weather.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.weather.R;
import com.example.weather.activity.MainActivity;
import com.example.weather.bean.WeatherDailyForecastList;
import com.example.weather.utils.WeatherUtils;

import java.text.SimpleDateFormat;
import java.util.List;

public class HourlyAdapter extends RecyclerView.Adapter<HourlyAdapter.VH> {
    // List to hold hourly forecast data
    List<WeatherDailyForecastList> weatherhourlyForecastLists;
    // Constructor for the adapter, initializes the list of hourly forecasts
    public HourlyAdapter(List<WeatherDailyForecastList> weatherhourlyForecastLists) {
        this.weatherhourlyForecastLists = weatherhourlyForecastLists;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the hourly forecast item layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_hourly, parent, false);
        // Return a new ViewHolder object for the layout
        return new VH(view);
    }

    // Bind data to the ViewHolder for each hourly forecast item
    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {

        WeatherDailyForecastList forecastList = weatherhourlyForecastLists.get(position);
        // Extract and format the date/time string
        String date = forecastList.getDt_txt();
        holder.tv_time.setText(date.substring(11, 16));
        // Get the weather icon and load it using Glide
        String icon = forecastList.getWeather().get(0).getIcon();
        String picUrl = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
        MainActivity mainActivity = (MainActivity) holder.iv.getContext();
        Glide.with(mainActivity).load(picUrl).into(holder.iv);
        // Display the temperature, converting to Fahrenheit if necessary
        if (mainActivity.mode == 0) {
            holder.tv_tem.setText(forecastList.getMain().getTemp() + "°");
        } else {
            holder.tv_tem.setText(WeatherUtils.changeC2F(forecastList.getMain().getTemp()) + "°");
        }
    }

    @Override
    public int getItemCount() {
        // Return the total number of items in the list
        return weatherhourlyForecastLists.size();
    }

    // ViewHolder class for hourly forecast items
    class VH extends RecyclerView.ViewHolder {
        // TextViews for displaying time and temperature
        TextView tv_time, tv_tem;
        // ImageView for displaying the weather icon
        ImageView iv;

        public VH(@NonNull View itemView) {
            super(itemView);
            // Initialize views by finding them by ID
            tv_tem = itemView.findViewById(R.id.tv_temperature);
            tv_time = itemView.findViewById(R.id.tv_time);
            iv = itemView.findViewById(R.id.iv_icon);
        }
    }
}
