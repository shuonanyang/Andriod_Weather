package com.example.weather.adapter;

import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weather.R;
import com.example.weather.listener.ItemClickListener;
import com.rainy.weahter_bg_plug.WeatherBg;

import java.util.List;

public class CityAdapter extends RecyclerView.Adapter<CityAdapter.VH> {
    // List to hold city data
    List<String> cityList;
    // Listener for item click events
    ItemClickListener itemClickListener;

    // Setter for item click listener
    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    // Constructor for the adapter taking a list of cities
    public CityAdapter(List<String> cityList) {
        this.cityList = cityList;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the city item layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_city, parent, false);
        // Return a new ViewHolder object
        return new VH(view);
    }

    // Bind city data to the ViewHolder
    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        // Get the city data at the current position
        String data = cityList.get(position);
        // Split the data to extract city name and temperature
        String[] split = data.split(";");
        // Set the city name and temperature range on the ViewHolder
        holder.tv_city.setText(split[0]);
        holder.tv_temperature.setText(split[1]);
        holder.tv_range.setText(String.format("TDD %s°\t\tCDD %s°", split[2], split[3]));
        // Set click listener for the ViewHolder's itemView
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (itemClickListener != null) {
                    // Trigger item click event
                    itemClickListener.onItemClick(position);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        // Return the size of the city list
        return cityList.size();
    }

    // ViewHolder class for city items
    class VH extends RecyclerView.ViewHolder{
        TextView tv_city, tv_range, tv_temperature;

        public VH(@NonNull View itemView) {
            super(itemView);
            // Initialize TextViews by finding them by ID
            tv_range = itemView.findViewById(R.id.tv_range);
            tv_city = itemView.findViewById(R.id.tv_city);
            tv_temperature = itemView.findViewById(R.id.tv_temperature);
        }

    }
}
