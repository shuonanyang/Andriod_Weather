package com.example.weather.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.weather.R;
import com.example.weather.activity.MainActivity;
import com.example.weather.bean.WeatherDailyForecastList;
import com.example.weather.utils.WeatherUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class DailyAdapter extends RecyclerView.Adapter<DailyAdapter.VH> {
    // List to hold weather forecast data
    List<WeatherDailyForecastList> weatherDailyForecastLists;
    // Constructor for the adapter taking a list of weather forecast data
    public DailyAdapter(List<WeatherDailyForecastList> weatherDailyForecastLists) {
        this.weatherDailyForecastLists = weatherDailyForecastLists;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the daily forecast item layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_daily, parent, false);
        return new VH(view);
    }

    // Bind forecast data to the ViewHolder
    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {

        WeatherDailyForecastList forecastList = weatherDailyForecastLists.get(position);
        // Extract weather icon code and main weather condition
        String icon = forecastList.getWeather().get(0).getIcon();
        String weather = forecastList.getWeather().get(0).getMain();
        // Format and set the date
        String date = new SimpleDateFormat("MM-dd").format(new Date(forecastList.getDt() * 1000));
        holder.tv_time.setText(date);
        // Extract and set max and min temperatures
        double max = forecastList.getTemp().getMax();
        double min = forecastList.getTemp().getMin();
        MainActivity mainActivity = (MainActivity) holder.iv.getContext();
        // Construct the URL for the weather icon
        String picUrl = "https://openweathermap.org/img/wn/" + icon + "@2x.png";
        // Use Glide to load and set the weather icon image
        Glide.with(mainActivity).load(picUrl).into(holder.iv);
        holder.tv_weather.setText(weather);
        // Display temperature in Celsius or Fahrenheit based on the user's preference
        if (mainActivity.mode == 0) {
            //Celsius
            holder.tv_tem.setText(max + "°/" + min + "°");
        } else {
            //Fahrenheit
            holder.tv_tem.setText(WeatherUtils.changeC2F(max) + "°/" + WeatherUtils.changeC2F(min) + "°");
        }

    }

    @Override
    public int getItemCount() {
        // Return the size of the forecast data list
        return weatherDailyForecastLists.size();
    }

    // ViewHolder class for daily forecast items
    class VH extends RecyclerView.ViewHolder {
        TextView tv_time, tv_tem, tv_weather;
        // ImageView for displaying weather icon
        ImageView iv;

        public VH(@NonNull View itemView) {
            super(itemView);
            // Initialize views by finding them by ID
            tv_tem = itemView.findViewById(R.id.tv_temperature);
            tv_time = itemView.findViewById(R.id.tv_time);
            tv_weather = itemView.findViewById(R.id.tv_weather);
            iv = itemView.findViewById(R.id.iv_icon);
        }
    }
}
